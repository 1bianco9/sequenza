using System;
using System.Collections.Generic;
using System.Linq;

public static class Sequenza
{
    public static int[] Verifica( int N ) 
    {
        int[] vettore = new int[N*(N+1)/2];
        int pos=0;
        if (N>=0)
        {
            for(int i=0; i<=N; i++)
            {
                for(int j=1; j<=i; j++)
                {
                    vettore[pos]=i;
                    pos++;
                }
            }
        }
        else
        {
            return new int[] { };
        }
        return vettore;
    }
}